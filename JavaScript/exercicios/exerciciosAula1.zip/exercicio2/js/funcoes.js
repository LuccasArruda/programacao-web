
function iniciar(){
    let nome = prompt('Qual é o seu nome?')
    let idade = prompt('Qual a sua idade?')
    let curso = prompt('Qual seu curso?')

    alert(`Olá ${nome}! Você tem ${idade} anos e faz o curso de ${curso}? Estou correto?`)
}