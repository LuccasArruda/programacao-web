
function alertVermelho(){
    alert("Você clicou no botão vermelho!")
}

function alertVerde(){
    alert("Você clicou no botão verde!")
}

function alertAmarelo(){
    alert("Você clicou no botão amarelo!")
}

